'use client';

import { useState } from 'react';
import { storeRecord, getRecord } from '../../../lib/eth';
import styles from '../../../styles/PatientRecord.module.css';
import Dashboard from '../../components/Dashboard';
import { ethers } from 'ethers';

export default function PatientRecordPage() {
  const [patientAddress, setPatientAddress] = useState('');
  const [cid, setCid] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [message, setMessage] = useState('');
  const [retrievedRecords, setRetrievedRecords] = useState([]);
  const [authorizedAddresses, setAuthorizedAddresses] = useState('');
  const [recordCount, setRecordCount] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const handleStoreRecord = async () => {
    try {
      let authorizedUsers = [];
  
      if (isPrivate) {
        authorizedUsers = authorizedAddresses
          .split(',')
          .map((address) => address.trim())
          .filter((address) => address !== '');
  
        if (authorizedUsers.length === 0) {
          throw new Error("Private record must have at least one authorized address.");
        }
      }
  
      await storeRecord(patientAddress, cid, isPrivate, authorizedUsers);
      setMessage('Record stored successfully');
    } catch (error) {
      setMessage('Failed to store record: ' + error.message);
    }
  };

  // const handleGetRecord = async () => {
  //   if (!ethers.isAddress(patientAddress)) {
  //     setMessage('Invalid Patient address.');
  //     return;
  //   }

  //   try {
  //     const records = await getRecord(patientAddress);
  //     setRetrievedRecords(records);
  //     if (records.length === 0) {
  //       setMessage("No records found.");
  //     } else {
  //       setMessage(`Found ${records.length} record(s).`);
  //     }
  //   } catch (error) {
  //     setMessage('Failed to retrieve records: ' + error.message);
  //   }
  // };

 
  return (
    <>
      <Dashboard />
      <main className={styles.container}>
        <h1 className={styles.title}>Patient Record</h1>

        <div className={styles.formContainer}>
          <div className={styles.formGroup}>
            <label htmlFor="patientAddress">Patient Address:</label>
            <input
              type="text"
              id="patientAddress"
              value={patientAddress}
              onChange={(e) => setPatientAddress(e.target.value)}
              placeholder="Enter Patient Address"
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="cid">Patient Record CID:</label>
            <textarea
              id="cid"
              value={cid}
              onChange={(e) => setCid(e.target.value)}
              placeholder="Enter CID of the Patient Record"
            />
          </div>

          {isPrivate && (
            <div className={styles.formGroup}>
              <label htmlFor="authorizedAddresses">Authorized Addresses (comma-separated):</label>
              <input
                type="text"
                id="authorizedAddresses"
                value={authorizedAddresses}
                onChange={(e) => setAuthorizedAddresses(e.target.value)}
                placeholder="0x123..., 0x456..., etc."
              />
            </div>
          )}
          <div className={styles.checkboxContainer}>
            <label>
              Private:
              <input
                type="checkbox"
                checked={isPrivate}
                onChange={() => setIsPrivate(!isPrivate)}
              />
            </label>
          </div>

          <div className={styles.buttonGroup}>
            <button className={styles.button} onClick={handleStoreRecord}>
              Store Record
            </button>
            {/* <button className={styles.button} onClick={handleGetRecord}>
              Get Records
            </button> */}
          </div>
        </div>

        {message && <div className={styles.message}>{message}</div>}

        {retrievedRecords.length > 0 && (
          <div className={styles.recordsContainer}>
            <h3>Retrieved Records:</h3>
            <ul className={styles.recordsList}>
              {retrievedRecords.map((record, index) => (
                <li key={index}>
                  <strong>CID:</strong> {record.cid}, <strong>Private:</strong> {record.isPrivate.toString()}
                </li>
              ))}
            </ul>
          </div>
        )}
      </main>
    </>
  );
}