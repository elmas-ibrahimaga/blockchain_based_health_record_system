'use client';

import { useState, useEffect } from 'react';
import { getAllPatients, getPatientInfo } from '../../../lib/eth'; 
import styles from '../../../styles/ViewRecords.module.css';
import Dashboard from '../../components/Dashboard';

export default function ViewAllPatientsPage() {
  const [patients, setPatients] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    // Fetch patient addresses dynamically from the contract
    const fetchPatientInfo = async () => {
      try {
        // Get all patient addresses
        const patientAddresses = await getAllPatients();

        // Fetch info for each patient
        const patientsData = await Promise.all(
          patientAddresses.map(async (address) => {
            const [recordCount, anyPrivate] = await getPatientInfo(address);
            return {
              address,
              recordCount,
              anyPrivate,
            };
          })
        );
        setPatients(patientsData);
      } catch (error) {
        setMessage('Failed to fetch patient data: ' + error.message);
      }
    };

    fetchPatientInfo();
  }, []);

  return (
    <>
      <Dashboard />
      <main className={styles.container}>
        <h1 className={styles.title}>All Patients</h1>

        {message && <div className={styles.message}>{message}</div>}

        <div className={styles.patientsContainer}>
          {patients.length === 0 ? (
            <p>No patients found.</p>
          ) : (
            <table className={styles.patientsTable}>
              <thead>
                <tr>
                  <th>Patient Address</th>
                  <th>Record Count</th>
                  <th>Has Private Records</th>
                </tr>
              </thead>
              <tbody>
                {patients.map((patient, index) => (
                  <tr key={index}>
                    <td>{patient.address}</td>
                    <td>{patient.recordCount}</td>
                    <td>{patient.anyPrivate ? 'Yes' : 'No'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </>
  );
}
