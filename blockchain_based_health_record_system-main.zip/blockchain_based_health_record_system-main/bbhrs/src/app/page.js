'use client';

import { useState } from 'react';

import { addToIPFS, getFromIPFS } from '../../lib/ipfs';
import Dashboard from '../components/Dashboard'; 
import styles from '../../styles/Home.module.css';

export default function HomePage() {
  const [input, setInput] = useState('');
  const [cid, setCid] = useState('');
  const [retrieved, setRetrieved] = useState('');

  const handleAdd = async () => {
    const newCid = await addToIPFS(input);
    setCid(newCid);
  };

  const handleRetrieve = async () => {
    const data = await getFromIPFS(cid);
    setRetrieved(data.toString());
  };

  return (
    <>
      <Dashboard /> {}
      <main className={styles.container}>
        <h1>IPFS with Helia</h1>
        <textarea
          className={styles.textarea}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          rows={5}
          placeholder="Enter patient record data"
        />
        <br />
        <button className={styles.button} onClick={handleAdd}>
          Add to IPFS
        </button>
        {cid && (
          <>
            <div className={styles.output}>
              <strong>CID:</strong> <span className={styles.cid}>{cid}</span>
            </div>
            <button className={styles.button} onClick={handleRetrieve}>
              Retrieve from IPFS
            </button>
            {retrieved && (
              <div className={styles.output}>
                <strong>Retrieved Data:</strong> {retrieved}
              </div>
            )}
          </>
        )}
      </main>
    </>
  );
}
