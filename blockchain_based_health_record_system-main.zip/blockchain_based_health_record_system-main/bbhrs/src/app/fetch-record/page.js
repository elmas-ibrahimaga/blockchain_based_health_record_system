'use client';

import { useState, useEffect } from 'react';
import { getPatientInfo, getPublicRecord, getRecord } from '../../../lib/eth';  // Assuming these functions exist in lib/eth.js
import styles from '../../../styles/PatientRecord.module.css';
import Dashboard from '../../components/Dashboard';
import { ethers } from 'ethers';
import { getFromIPFS } from '../../../lib/ipfs';

export default function FetchRecordPage() {
    const [patientAddress, setPatientAddress] = useState('');
    const [recordIndex, setRecordIndex] = useState('');
    const [authorizedAddress, setAuthorizedAddress] = useState('');
    const [isPrivate, setIsPrivate] = useState(false);
    const [message, setMessage] = useState('');
    const [fetchedRecord, setFetchedRecord] = useState(null);
    const [recordOptions, setRecordOptions] = useState([]); // To hold available records for the patient
    const [patientData, setPatientData] = useState('');


    useEffect(() => {
        const fetchPatientInfo = async () => {
            if (!ethers.isAddress(patientAddress)) {
                setMessage('Invalid patient address');
                return;
            }

            try {
                // Fetch patient record count and private status
                const [recordCount, anyPrivate] = await getPatientInfo(patientAddress);

                if (recordCount === 0) {
                    setMessage('No records found for this patient');
                } else {
                    setMessage('');
                    // Generate record options based on the available records
                    const options = Array.from({ length: recordCount }, (_, index) => index);
                    setRecordOptions(options);
                }
            } catch (error) {
                setMessage('Error fetching patient info: ' + error.message);
            }
        };

        if (patientAddress) {
            fetchPatientInfo();
        } else {
            setRecordOptions([]);
        }
    }, [patientAddress]);

    const handleFetchRecord = async () => {
        try {
          // Validate patient address and record index
          if (!ethers.isAddress(patientAddress)) {
            setMessage('Invalid patient address');
            return;
          }
          if (recordIndex === '' || isNaN(recordIndex)) {
            setMessage('Please select a valid record index');
            return;
          }
      
          const recordIndexParsed = parseInt(recordIndex);
          let cid;
      
          if (isPrivate) {
            // Validate authorized address
            if (!ethers.isAddress(authorizedAddress)) {
              setMessage('Invalid authorized address');
              return;
            }
      
            const result = await getRecord(patientAddress, recordIndexParsed, authorizedAddress);
            cid = result.cid;
          } else {
            cid = await getPublicRecord(patientAddress, recordIndexParsed);
          }
      
          // Fetch and parse from IPFS
          const ipfsData = await getFromIPFS(cid);
          let parsedData;
          try {
            parsedData = JSON.parse(ipfsData);
          } catch (e) {
            parsedData = ipfsData; // fallback if not JSON
          }
      
          setFetchedRecord({
            cid: cid,
            content: parsedData,
          });
      
          setMessage('Record fetched successfully');
        } catch (error) {
          setMessage('Failed to fetch record');
        }
      };

    return (
        <>
            <Dashboard />
            <main className={styles.container}>
                <h1 className={styles.title}>Fetch Patient Record</h1>

                <div className={styles.formContainer}>
                    <div className={styles.formGroup}>
                        <label htmlFor="patientAddress">Patient Address:</label>
                        <input
                            type="text"
                            id="patientAddress"
                            value={patientAddress}
                            onChange={(e) => setPatientAddress(e.target.value)}
                            placeholder="Enter Patient Address"
                        />
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="recordIndex">Record Index:</label>
                        <select
                            id="recordIndex"
                            value={recordIndex}
                            onChange={(e) => setRecordIndex(e.target.value)}
                        >
                            <option value="">Select a record</option>
                            {recordOptions.map((index) => (
                                <option key={index} value={index}>
                                    Record {index + 1}
                                </option>
                            ))}
                        </select>
                    </div>

                    {isPrivate && (
                        <div className={styles.formGroup}>
                            <label htmlFor="authorizedAddress">Authorized Address:</label>
                            <input
                                type="text"
                                id="authorizedAddress"
                                value={authorizedAddress}
                                onChange={(e) => setAuthorizedAddress(e.target.value)}
                                placeholder="Enter Authorized Address"
                            />
                        </div>
                    )}

                    <div className={styles.checkboxContainer}>
                        <label>
                            Private Record:
                            <input
                                type="checkbox"
                                checked={isPrivate}
                                onChange={() => setIsPrivate(!isPrivate)}
                            />
                        </label>
                    </div>

                    <div className={styles.buttonGroup}>
                        <button className={styles.button} onClick={handleFetchRecord}>
                            Fetch Record
                        </button>
                    </div>
                </div>


                {fetchedRecord && (
                    <div className={styles.recordContainer}>
                        <h3>Fetched Record:</h3>
                        <p><strong>CID:</strong> {fetchedRecord.cid}</p>
                        <p><strong>IPFS Content:</strong></p>
                        <pre>{typeof fetchedRecord.content === 'object' ? JSON.stringify(fetchedRecord.content, null, 2) : fetchedRecord.content}</pre>
                    </div>
                )}
                {message && <div className={styles.message}>{message}</div>}

            </main>
        </>
    );
}
