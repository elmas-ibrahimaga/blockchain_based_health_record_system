'use client';

import Link from 'next/link';
import styles from '../../styles/Dashboard.module.css'; 

export default function Dashboard() {
  return (
    <nav className={styles.navbar}>
      <Link className={styles.link} href="/">Home</Link>
      <Link className={styles.link} href="/patient-record">Patient Records</Link>
      <Link className={styles.link} href="/view-records">View Records</Link>
      <Link className={styles.link} href="/fetch-record">Fetch Record</Link>
    </nav>
  );
}
